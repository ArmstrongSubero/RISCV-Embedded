/*
 * File: Main.c
 * Author: Armstrong Subero
 * MCU: CH32V003F4P6 w/Int OSC @ 48 MHz, 3.3v
 * Program: 00_Project
 * Compiler: WCH Toolchain (GCC8, MounRiver Studio v2.20)
 * Program Version: 1.1
 *                  * Cleaned up code
 *                  * Added additional comments
 *                
 * Program Description: This Program is a blank project for using the CH32V003F4P6
 * 
 * Hardware Description: The CH32V003f4P6 is connected as per 

 * Created August 16th, 2025,  12:02 AM
 * Updated January 31st, 2026, 04:52 PM
 */

/*******************************************************************************
 *Includes and defines
 ******************************************************************************/
#include "ch32v00x.h"

void initMain()
{
    // put your setup code here
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
    SystemCoreClockUpdate();
}

int main(void)
{
    initMain();

    while(1)
    {
       // put your main looping code here 
    }
}

